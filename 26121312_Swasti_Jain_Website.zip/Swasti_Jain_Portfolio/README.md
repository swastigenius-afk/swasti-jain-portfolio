# Swasti Jain | Student Portfolio

A responsive, single-page student portfolio built with semantic HTML, custom CSS, and a small JavaScript enhancement. The visual system combines a midnight background, lavender accents, sage and warm-neutral surfaces, a serif display font, and a clean sans-serif body font.

## Website files

- `index.html` - page structure, portfolio content, and accessible navigation
- `styles.css` - typography, colour system, layout, responsive design, hover and focus states
- `script.js` - accessible mobile navigation and automatic footer year

## Repository

https://github.com/swastigenius-afk/swasti-jain-portfolio

## Publish with GitHub Pages

1. Upload these four files to the **root** of the `main` branch. `index.html` must be at the top level of the selected publishing folder.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then click **Save**.
5. After GitHub Pages finishes publishing, use the **Visit site** link shown in Pages settings. The expected project-site address is `https://swastigenius-afk.github.io/swasti-jain-portfolio/`; confirm it is live before submitting.

GitHub's documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## CSS concepts demonstrated

- Element selectors: `body`, `a`, `button`, `h1`, `h2`, `h3`, `p`, and `::selection`
- Class selectors: reusable classes including `.container`, `.button`, `.skill-card`, and `.project-card`
- ID selectors: navigation and section targets including `#main`, `#about`, `#projects`, and `#contact`
- CSS custom properties in `:root` for reusable colours, fonts, shadows, and radii
- Flexbox for navigation, button groups, labels, contact links, and footer alignment
- CSS Grid for hero, about, education, skills, project, and contact layouts
- Positioning for the sticky header, decorative elements, and project-card artwork
- Responsive media queries for tablet and mobile screens
- Hover/focus states, skip link, descriptive labels, and reduced-motion support

## Personalisation note

The draft uses the supplied name Swasti Jain, Grade 12, and project themes discussed during preparation: business strategy, mathematics innovation, and the SOLE-MATES advertising concept. Confirm that each project description matches the work you actually completed. Add additional personal contact details only if you are comfortable sharing them publicly.
